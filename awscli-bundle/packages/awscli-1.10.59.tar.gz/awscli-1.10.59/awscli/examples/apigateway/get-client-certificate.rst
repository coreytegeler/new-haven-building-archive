**To get a client certificate in the specified region**

Command::

  aws apigateway get-client-certificate --client-certificate-id a1b2c3 --region us-west-2

